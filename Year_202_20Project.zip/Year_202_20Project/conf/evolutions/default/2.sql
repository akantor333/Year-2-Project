# --- !Ups
delete from submitted_work;
delete from genre;

insert into genre (name) values ('Fantasy');
insert into genre (name) values ('Horror');
insert into genre (name) values ('Crime');
insert into genre (name) values ('Western');
insert into genre (name) values ('Romance');
insert into genre (name) values ('Thriller');
insert into genre (name) values ('Science Fiction');
insert into genre (name) values ('Short Story');
insert into genre (name) values ('Mystery');
insert into genre (name) values ('Biography');
insert into genre (name) values ('Adventure');

