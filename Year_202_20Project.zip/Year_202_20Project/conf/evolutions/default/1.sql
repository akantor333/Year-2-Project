# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table comment (
  id                            bigint auto_increment not null,
  text                          TEXT,
  user_username                 varchar(255),
  work_id                       bigint,
  constraint pk_comment primary key (id)
);

create table donation (
  id                            bigint auto_increment not null,
  donation_email                varchar(255),
  userid                        varchar(255),
  constraint uq_donation_userid unique (userid),
  constraint pk_donation primary key (id)
);

create table genre (
  id                            bigint auto_increment not null,
  name                          varchar(255),
  constraint pk_genre primary key (id)
);

create table genre_submitted_work (
  genre_id                      bigint not null,
  submitted_work_id             bigint not null,
  constraint pk_genre_submitted_work primary key (genre_id,submitted_work_id)
);

create table submitted_work (
  id                            bigint auto_increment not null,
  name                          varchar(255),
  rating                        bigint,
  text                          TEXT,
  type                          varchar(255),
  user_username                 varchar(255),
  constraint pk_submitted_work primary key (id)
);

create table user (
  username                      varchar(255) not null,
  role                          varchar(255),
  email                         varchar(255),
  name                          varchar(255),
  password                      varchar(255),
  donation                      varchar(255),
  constraint pk_user primary key (username)
);

alter table comment add constraint fk_comment_user_username foreign key (user_username) references user (username) on delete restrict on update restrict;
create index ix_comment_user_username on comment (user_username);

alter table comment add constraint fk_comment_work_id foreign key (work_id) references submitted_work (id) on delete restrict on update restrict;
create index ix_comment_work_id on comment (work_id);

alter table donation add constraint fk_donation_userid foreign key (userid) references user (username) on delete restrict on update restrict;

alter table genre_submitted_work add constraint fk_genre_submitted_work_genre foreign key (genre_id) references genre (id) on delete restrict on update restrict;
create index ix_genre_submitted_work_genre on genre_submitted_work (genre_id);

alter table genre_submitted_work add constraint fk_genre_submitted_work_submitted_work foreign key (submitted_work_id) references submitted_work (id) on delete restrict on update restrict;
create index ix_genre_submitted_work_submitted_work on genre_submitted_work (submitted_work_id);

alter table submitted_work add constraint fk_submitted_work_user_username foreign key (user_username) references user (username) on delete restrict on update restrict;
create index ix_submitted_work_user_username on submitted_work (user_username);


# --- !Downs

alter table comment drop constraint if exists fk_comment_user_username;
drop index if exists ix_comment_user_username;

alter table comment drop constraint if exists fk_comment_work_id;
drop index if exists ix_comment_work_id;

alter table donation drop constraint if exists fk_donation_userid;

alter table genre_submitted_work drop constraint if exists fk_genre_submitted_work_genre;
drop index if exists ix_genre_submitted_work_genre;

alter table genre_submitted_work drop constraint if exists fk_genre_submitted_work_submitted_work;
drop index if exists ix_genre_submitted_work_submitted_work;

alter table submitted_work drop constraint if exists fk_submitted_work_user_username;
drop index if exists ix_submitted_work_user_username;

drop table if exists comment;

drop table if exists donation;

drop table if exists genre;

drop table if exists genre_submitted_work;

drop table if exists submitted_work;

drop table if exists user;

