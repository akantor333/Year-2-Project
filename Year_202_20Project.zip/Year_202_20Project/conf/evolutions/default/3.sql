# --- !Ups
delete from user;
insert into user (username,role,email,name, password) values ('admin', 'admin','dave@admin.com','Dave', 'Admin123');
insert into user (username,role,email,name, password) values ('user', 'user','gab@user.com','Gab', 'User123');