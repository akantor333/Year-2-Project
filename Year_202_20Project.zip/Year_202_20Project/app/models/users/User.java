package models.users;

import java.util.*;
import javax.persistence.*;
import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;
import models.*;

@Entity
@Table (name = "user")

public class User extends Model {
    @Id
    private String username;

    @Constraints.Required 
    private String role;

    @Constraints.Required 
    private String email;

    @Constraints.Required
    private String name;
    
    @Constraints.Required
    private String password;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<SubmittedWork> works;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<Comment> comments;

    private String donation;

    public static final Finder<Long, User> find = new Finder<>(User.class);

    public static User authenticate(String username, String password) {
        return find.query().where().eq("username", username).eq("password", password).findUnique();
    }
    public static User getUserById(String id) {
        if (id == null) {
            return null;
        } else {
            return find.query().where().eq("username", id).findUnique();
        }
    }

    public User() {

    }

    public User(String username, String role, String email, String name, String password, List<SubmittedWork> works, List<Comment> comments) {
        this.username = username;
        this.role = role;
        this.email = email;
        this.name = name;
        this.password = password;
        this.works = works;
        this.comments = comments;
    }


    public List<Comment> getComments() {
        return this.comments;
    }

    public void setComments(List<Comment> comments) {
        this.comments = comments;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setWorks(List<SubmittedWork> works){
        this.works = works;
    }

    public List<SubmittedWork> getWorks(){
        return works;
    }

    public void addWork(SubmittedWork work){
        works.add(work);
    }

    public void addComment(Comment c){
        if(!comments.contains(c)){
        comments.add(c);}
    }

}